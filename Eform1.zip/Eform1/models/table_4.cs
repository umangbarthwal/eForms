﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eform1.models
{
    public class table_4
    {
        public int UID_F { get; set; }
        public int UID_Q { get; set; }
        public string Answer { get; set; }

    }
}
